﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rpg
{
    class Program
    {
       
        const int Width = 120;
        const int Height = 60;
        static string[,] buffer = null;
        static ConsoleCanvasString Canvas = new ConsoleCanvasString(Width,Height);
        static Player player = null;
        static Dictionary<int, Monster> monsterDitct = new Dictionary<int, Monster>();
        static skill normal_damage(0,)

        static void Main(string[] args)
        {
         player = new Player("雾亥", 1000, 1000, 25, 40);
        
         player.skillsList.Add()
         buffer = Canvas.GetBuffer();
          

        }
    }
}
